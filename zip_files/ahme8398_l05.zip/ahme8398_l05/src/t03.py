"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-02-09"
-------------------------------------------------------
"""
# Imports
from functions import vowel_count
# Constants

s = input("Enter a string: ")

count = vowel_count(s)

print("Vowel count:", count)
        