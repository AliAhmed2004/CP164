"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-02-09"
-------------------------------------------------------
"""
# Imports
from functions import hash_table
# Constants

values = ['Dark City, 1998', 'Zulu, 1964', 'I Am Legend, 2007', 'Omega Man, The, 1971']
hash_table(7, values)
