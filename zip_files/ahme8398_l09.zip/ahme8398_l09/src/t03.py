"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-02-09"
-------------------------------------------------------
"""
# Imports
from Hash_Set_array import Hash_Set
# Constants

hset = Hash_Set(3)

hset.insert(5)

hset.insert(10)

hset.insert(15)

hset.debug()