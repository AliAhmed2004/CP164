
"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-02-09"
-------------------------------------------------------
"""
# Imports
from test_Sorts_array import test_sort, SORTS
# Constants

for sort in SORTS:
    test_sort(sort[0], sort[1])