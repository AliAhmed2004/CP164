"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""
# Imports
from functions import matrixes_multiply
# Constants


rows = int(input('Enter number of rows: '))
cols = int(input('Enter number of column: '))

print()
print('Enter values for matrix A')

A = [[int(input(f"Column {j+1}; Enter element {i+1}: "))
      for j in range(cols)] for i in range(rows)]

print()
print('Enter values for matrix B ')

B = [[int(input(f"Column {j+1}; Enter element {i+1}: "))
      for j in range(cols)] for i in range(rows)]

print()

print('Matrix A :')
for i in A:
    print(i)

print()

print('Matrix B :')
for i in B:
    print(i)
print("")
print(matrixes_multiply(A, B))
