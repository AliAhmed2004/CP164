"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose
# Constants


row = int(input("Enter the number of rows: "))
col = int(input("Enter the number of columns: "))

matrix = []
print("Enter the entries row-wise:")

for i in range(row):
    a = []
    for j in range(col):
        a.append(int(input()))
    matrix.append(a)

print(matrix_transpose(matrix))
