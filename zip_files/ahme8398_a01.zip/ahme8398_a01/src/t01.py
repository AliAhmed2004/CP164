"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""
# Imports
from functions import clean_list
# Constants

input_string = input('Enter elements of a list separated by space: ')

user_list = input_string.split()

for i in range(len(user_list)):
    user_list[i] = int(user_list[i])

clean_list(user_list)
