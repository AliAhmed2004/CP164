"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""
# Imports
from functions import file_analyze
# Constants

fv = open("movies.txt", "r", encoding="utf-8")
print(file_analyze(fv))
fv.close()
