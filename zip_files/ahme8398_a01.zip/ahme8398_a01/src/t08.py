"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""
# Imports
from functions import pig_latin
# Constants


word = str(input("Enter a word: "))

final_result = pig_latin(word)

print(" ")
print("Word: {}".format(word))
print("Pig-Latin: {}".format(final_result))
