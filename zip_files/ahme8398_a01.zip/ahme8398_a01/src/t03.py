"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""
# Imports
from functions import find_subs
# Constants

string = str(input("Enter a string: "))
sub = str(input("Enter a sub value: "))

print("\n")

print(find_subs(string, sub))
