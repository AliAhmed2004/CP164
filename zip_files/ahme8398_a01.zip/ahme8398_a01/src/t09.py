"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-22"
-------------------------------------------------------
"""
# Imports
from functions import shift
# Constants


f = open("pelee.txt", "r")
w = open("shift.txt", "w")

string_1 = f.readlines()


string = ""

for line in string_1:
    string += line

print(string, "\n")

n = int(input("Enter the number of letters to shift: "))

estring = shift(string, n)

with w as file:
    file.write(estring)
