"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-01-21"
-------------------------------------------------------
"""
# Imports
from functions import is_valid
# Constants


name = str(input("Enter a variable name: "))

answer = is_valid(name)

print("{} : {}".format(name, answer))
