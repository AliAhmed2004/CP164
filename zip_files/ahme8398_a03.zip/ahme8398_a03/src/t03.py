"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Ali Ahmed
ID:      169038398
Email:   ahme8398@mylaurier.ca
__updated__ = "2023-02-02"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome_stack
# Constants 

string = input("Enter a string: ")
result = is_palindrome_stack(string)

print(result)